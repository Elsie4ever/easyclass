*********************
***
***	README
***
*********************

1. Again, we improved our website design and hopefully it looks good to you. Although this may contribute nothing towards our deliverable grade, since we're taking HCI class, we believe providng a smooth and agreeable user experience should be our everlasting concerns throughout this course. If, however, this counts for extra credits, we'd be ecstatic to accept them. 

2. The above lines are just joking. Life is full of joy, so stay happy~!

3. Regarding our deliverable, any kinds of feedback on anything (the website) will be greatly appreciated, either good or bad. Specifically, if you think we did something wrong or stupid or there is anything we could do better, pleaaaa~~~ssssse, shout it out to us. We'd like to express our sincere gratitude for that in advance. Thank you~!!!
 
4. I still doubt if someone really cares what we write here...

5. Thanks for your review and wish you have a good day!

(oops~, sry, just one last thing before let you go: in HCI we all suffer, and we know it is definitely no picnic for all of us, so we wish you could grade us gently but also responsibly, because that's what we would do to you, thank you~!)

Alright, now you're good to go, click me (actually not me but the following link):
http://www.cim.mcgill.ca/~jer/courses/hci/project/2017/www.ece.mcgill.ca/~jju2/hci/notebook/hi_fi.html


