<?php
use App\Course;
?>

<title>easyClass</title>
<link href="/css/addclass.css" rel="stylesheet">
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->position == "Student"): ?>
    <ul class="tabs" role="tablist">
        <li>
            <input type="radio" name="tabs" id="tab1" checked />
            <label for="tab1"
                   role="tab"
                   aria-selected="true"
                   aria-controls="panel1"
                   tabindex="0">Class</label>
            <div id="tab-content1"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="description"
                 aria-hidden="false">
                <div class="col-lg-12 addcontent">
                    <p>Add Class</p>
                </div>
                <!--Class name-->
                <!--need change-->
                <form method="post" action="/home">
                    <?php echo e(csrf_field()); ?>

                    <select type="text" class="form-control"  name="coursenameStudent">
                        <?php $__currentLoopData = $user_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option>Data</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="submit">
                </form>
            </div>
        </li>
    </ul>
    <script>
        $(function() {
            // Bind Click event to the drop down navigation button
            $(".nav-button").click(function() {
                /*  Toggle the CSS closed class which reduces the height of the UL thus
                 hiding all LI apart from the first */
                $(this).parent().parent().toggleClass("closed");
            });

        });
    </script>
    <?php else: ?>
    <ul class="tabs" role="tablist">
        <li>
            <input type="radio" name="tabs" id="tab1" checked />
            <label for="tab1"
                   role="tab"
                   aria-selected="true"
                   aria-controls="panel1"
                   tabindex="0">Class</label>
            <div id="tab-content1"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="description"
                 aria-hidden="false">
                <div class="col-lg-12 addcontent">
                    <p>Create</p>
                </div>
                <!--Class name-->
                <!--need change-->
                <form method="post" action="/home">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" name="coursename">
                <input type="submit" name="submit">
                </form>
            </div>
        </li>
    </ul>
    <script>
        $(function() {
            // Bind Click event to the drop down navigation button
            $(".nav-button").click(function() {
                /*  Toggle the CSS closed class which reduces the height of the UL thus
                 hiding all LI apart from the first */
                $(this).parent().parent().toggleClass("closed");
            });

        });
    </script>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>