<?php
use App\Course;
use App\Lecture;
use App\Topic;
use App\Understand;
use App\Msgunderstd;
?>

<title>easyClass</title>
<link href="css/home.css" rel="stylesheet">
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->position == "Student"): ?>
    <ul class="tabs" role="tablist">
        <li>
            <input type="radio" name="tabs" id="tab1" href="#tab1" checked />
            <label for="tab1"
                   role="tab"
                   aria-selected="true"
                   aria-controls="panel1"
                   tabindex="0">Class</label>
            <div id="tab-content1"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="description"
                 aria-hidden="false">
                <div class="col-lg-12 addBtn">Add Class
                    <a href="<?php echo e(url('/addclass')); ?>"><image src="/img/add.png" style="height: 50px"/></a>
                </div>
                <ul>
                    <?php $__currentLoopData = $user_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user_course->user_id==Auth::user()->id): ?>
                    <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="col-lg-6 courses">Course Name: <?php echo e(Course::where('id',$user_course->course_id)->first()->coursename); ?></div>
                        <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lecture->course_id==$user_course->course_id): ?>
                        <ul class="drop-down closed col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="nav-button">Lecture: <?php echo e($lecture->lecturename); ?></div></li>
                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lecture->id==$topic->lecture_id): ?>
                            <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topicDiv" data-topicid="<?php echo e($topic->id); ?>">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 topics" href="#">Topic: <?php echo e($topic->topicname); ?></div>
                                <button type="button" class="js-like-button like-btn" id="questionBtn"><img src="/img/question-green.png" style="height: 20px"/>︎&nbsp; <?php echo e(Auth::user()->understands()->where('topic_id', $topic->id)->first() ? Auth::user()->understands()->where('topic_id', $topic->id)->first()->understand == 1 ? 'Cancel Request' : 'I don\'t understand' : 'I don\'t understand'); ?></button>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </li>
        <script>
            var token = '<?php echo e(Session::token()); ?>';
            var urlLike = '<?php echo e(route('understand')); ?>';
            $('.js-like-button').on('click', function(evt) {
                evt.preventDefault();
                var $btn = $(this);
                var liked = ($btn.text().match('Cancel Request') === null);
                var topicId = evt.target.parentNode.dataset['topicid'];
                console.log(liked);
                $.ajax({
                    method: 'POST',
                    url:urlLike,
                    data:{liked:liked,topicId:topicId,_token:token}
                })
                    .done(function(){
                    });
                $btn.html('<img class="like-btn__spinner" src="http://jxnblk.com/loading/loading-bars.svg" alt="loading"/> Saving');
                if (liked) {
                    $btn.html('<img src="/img/question-green.png" style="height: 20px"/>︎&nbsp; Cancel Request');
                } else {
                    $btn.html('<img src="/img/question-green.png" style="height: 20px"/>︎&nbsp; I don\'t understand');
                }

            });
        </script>
        <li>
            <input type="radio" name="tabs" id="tab2" href="#tab2"/>
            <label for="tab2"
                   role="tab"
                   aria-selected="false"
                   aria-controls="panel2"
                   tabindex="1">Chat room</label>
            <div id="tab-content2"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="specification"
                 aria-hidden="true">
                <!--to be changed, only ui for now-->
                <div class="col-lg-12">
                <form method="POST" action="/swithclass" class="col-lg-12">
                    <?php echo e(csrf_field()); ?>

                    <p class="">Switch Classroom</p>
                    <select type="text" class="form-control" name="switch_class">
                        <?php $__currentLoopData = $user_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user_course->user_id==Auth::user()->id): ?>
                        <option data-courseid="<?php echo e($user_course->course_id); ?>" ><?php echo e(Course::where('id',$user_course->course_id)->first()->coursename); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="sendMessage col-lg-2 col-md-2" id="switchclass">Confirm</button>
                </form></div>
                <div class="container_chat clearfix">
                    <?php if($currentcourse!=''): ?>
                    <div class="chat">
                        <div class="chat-header clearfix">
                            <div class="chat-about">
                                <div class="chat-with">Chat room for <?php echo e($currentcourse); ?></div>
                                <div class="chat-num-messages"></div>
                            </div>
                            <i class="fa fa-star"></i>
                        </div> <!-- end chat-header -->

                        <div class="chat-history">
                            <ul class="messageDivv" id="msg">
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Course::where('id',$message->course_id)->first()->coursename==$currentcourse): ?>
                                    <?php if(Auth::user()->name == Auth::user()->where('id',$message->user_id)->first()->name): ?>
                                    <li style="width: 100%">
                                        <div class="message-data align-right">
                                            <span class="message-data-time"><?php echo e($message->created_at); ?></span>
                                        </div>
                                        <div class="message other-message float-right">
                                            <?php echo e($message->content); ?>

                                        </div>
                                        <div class="col-lg-12" data-messageid="<?php echo e($message->id); ?>">
                                            <?php if( Auth::user()->msgunderstands()->where('message_id',$message->id)->first()): ?>
                                            <button class="float-right msgUnderstand"><img class="understandimg" style="width: 30px;height:auto;" src="img/ques-red.png"/></button>
                                            <?php else: ?>
                                            <button class="float-right msgUnderstand"><img class="understandimg" style="width: 30px;height:auto;" src="img/ques-black.png"/></button>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                    <?php else: ?>
                                    <li style="width: 100%">
                                        <div class="message-data">
                                            <span class="message-data-time"><?php echo e($message->created_at); ?></span>
                                        </div>
                                        <div class="message my-message">
                                            <?php echo e($message->content); ?>

                                        </div>
                                        <div class="col-lg-12" data-messageid="<?php echo e($message->id); ?>">
                                            <?php if( Auth::user()->msgunderstands()->where('message_id',$message->id)->first()): ?>
                                            <button class="float-left msgUnderstand"><img class="understandimg" style="width: 30px;height:auto;" src="img/ques-red.png"/></button>
                                            <?php else: ?>
                                            <button class="float-left msgUnderstand"><img class="understandimg" style="width: 30px;height:auto;" src="img/ques-black.png"/></button>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                        </div> <!-- end chat-history -->
                        <div style="background-color: #2e3436;padding:20px;border-radius: 0px 0px 10px 10px">
                            <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="class" data-class="<?php echo e($currentcourse); ?>" value="<?php echo e($currentcourse); ?>" >
                                <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>" >
                            <input name="msgcontent" id="message-to-send1" class="form-control" placeholder ="Type your message" rows="3">
                            <i class="fa fa-file-o"></i> &nbsp;&nbsp;&nbsp;
                            <i class="fa fa-file-image-o"></i>

                            <button class="sendMessage float-right" id="sendMessage" style="margin-top: 10px">Send</button>
                        </div>
                      <!-- end chat-message -->
                    </div> <!-- end chat -->
                    <?php endif; ?>
                </div> <!-- end container -->
            </div>
        </li>
       <script>
            $(document).on('click','#sendMessage', function(evt) {
                evt.preventDefault();
                var $btn = $(this);
                var contentmsg = $('input[name=msgcontent]').val();
                console.log(contentmsg);
                var courseId = $('input[name=class]').val();
                var userId = $('input[name=user]').val();
                $.ajax({
                    method: 'POST',
                    url:'/sendMessage',
                    data:{contentmsg:contentmsg,courseId:courseId,_token:$('input[name=_token]').val(),userId:userId},
                    success: function(data){
                        $('#msg').append('<li style="width: 100%"><div class="message-data align-right"><span class="message-data-name"><i class="fa fa-circle online"></i></span> <span class="message-data-time">'+data.created_at+'</span> </div> <div class="message other-message float-right">'+data.content+' </div> </li>')
                    }
                });
                $('input[name=msgcontent]').val('');

            });
        </script>
    </ul>
    <script>
        $(function() {
            // Bind Click event to the drop down navigation button
            $(".nav-button").click(function() {
                /*  Toggle the CSS closed class which reduces the height of the UL thus
                 hiding all LI apart from the first */
                $(this).parent().parent().toggleClass("closed");
            });

        });
    </script>

    <?php else: ?>
    <ul class="tabs" role="tablist">
        <li>
            <input type="radio" name="tabs" id="tab1" checked />
            <label for="tab1"
                   role="tab"
                   aria-selected="true"
                   aria-controls="panel1"
                   tabindex="0">Class</label>
            <div id="tab-content1"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="description"
                 aria-hidden="false">
                    <div class="col-lg-12 addBtn">Create Class
                        <a href="<?php echo e(url('/addclass')); ?>"><image src="/img/add.png" style="height: 50px"/></a>
                    </div>

                    <ul>
                        <?php $__currentLoopData = $user_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user_course->user_id==Auth::user()->id): ?>
                        <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 coursescourses">Course Name: <?php echo e(Course::where('id',$user_course->course_id)->first()->coursename); ?></div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 addBtn">Add Content
                                <a href="<?php echo e(url('/addcontent')); ?>"><image src="/img/small-add.png" style="height: 30px"/></a>
                            </div>
                            <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lecture->course_id==$user_course->course_id): ?>
                            <ul class="drop-down closed col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="nav-button">Lecture: <?php echo e($lecture->lecturename); ?></div></li>
                                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lecture->id==$topic->lecture_id): ?>
                                <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topicDiv">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 topics" href="#">Topic: <?php echo e($topic->topicname); ?></div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 understand"><?php echo e(Understand::where('understand',1)->where('topic_id',$topic->id)->count()); ?> Student don't understand</div>
                                </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </div>
        </li>

        <li>
            <input type="radio" name="tabs" id="tab2" />
            <label for="tab2"
                   role="tab"
                   aria-selected="false"
                   aria-controls="panel2"
                   tabindex="0">Chat room</label>
            <div id="tab-content2"
                 class="tab-content"
                 role="tabpanel"
                 aria-labelledby="specification"
                 aria-hidden="true">
                <!--to be changed, only ui for now-->
                <div class="col-lg-12">
                    <form method="POST" action="/swithclass" class="col-lg-12">
                        <?php echo e(csrf_field()); ?>

                        <p class="">Switch Classroom</p>
                        <select type="text" class="form-control" name="switch_class">
                            <?php $__currentLoopData = $user_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user_course->user_id==Auth::user()->id): ?>
                            <option data-courseid="<?php echo e($user_course->course_id); ?>" ><?php echo e(Course::where('id',$user_course->course_id)->first()->coursename); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button class="sendMessage col-lg-2 col-md-2" id="switchclass">Confirm</button>
                    </form></div>
                <div class="container_chat clearfix">
                    <?php if($currentcourse!=''): ?>
                    <div class="chat">
                        <div class="chat-header clearfix">
                            <div class="chat-about">
                                <div class="chat-with">Chat room for <?php echo e($currentcourse); ?></div>
                                <div class="chat-num-messages"></div>
                            </div>
                            <i class="fa fa-star"></i>
                        </div> <!-- end chat-header -->

                        <div class="chat-history">
                            <ul class="messageDivv" id="msg">
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Course::where('id',$message->course_id)->first()->coursename==$currentcourse): ?>
                                <?php if(Auth::user()->name == Auth::user()->where('id',$message->user_id)->first()->name): ?>
                                <li style="width: 100%">
                                    <div class="message-data align-right">
                                        <span class="message-data-time"><?php echo e($message->created_at); ?></span>
                                    </div>
                                    <div class="message other-message float-right">
                                        <?php echo e($message->content); ?>

                                    </div>
                                    <?php if(Msgunderstd::where('buttonPressed',0)->where('message_id',$message->id)->count()>0): ?>
                                    <div class="col-lg-12 float-right" style="color:red" data-messageid="<?php echo e($message->id); ?>">
                                        <?php echo e(Msgunderstd::where('buttonPressed',0)->where('message_id',$message->id)->count()); ?> student don't understand this
                                    </div>
                                    <?php endif; ?>
                                </li>
                                <?php else: ?>
                                <li style="width: 100%">
                                    <div class="message-data">
                                        <span class="message-data-time"><?php echo e($message->created_at); ?></span>
                                    </div>
                                    <div class="message my-message">
                                        <?php echo e($message->content); ?>

                                    </div>
                                    <?php if(Msgunderstd::where('buttonPressed',0)->where('message_id',$message->id)->count()>0): ?>
                                    <div class="col-lg-12 float-right" style="color:red" data-messageid="<?php echo e($message->id); ?>">
                                        <?php echo e(Msgunderstd::where('buttonPressed',0)->where('message_id',$message->id)->count()); ?> student don't understand this
                                    </div>
                                    <?php endif; ?>
                                </li>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                        </div> <!-- end chat-history -->
                        <div style="background-color: #2e3436;padding:20px;border-radius: 0px 0px 10px 10px">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="class" data-class="<?php echo e($currentcourse); ?>" value="<?php echo e($currentcourse); ?>" >
                            <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>" >
                            <input name="msgcontent" id="message-to-send1" class="form-control" placeholder ="Type your message" rows="3">
                            <i class="fa fa-file-o"></i> &nbsp;&nbsp;&nbsp;
                            <i class="fa fa-file-image-o"></i>

                            <button class="sendMessage float-right" id="sendMessage" style="margin-top: 10px">Send</button>
                        </div>
                        <!-- end chat-message -->
                    </div> <!-- end chat -->
                    <?php endif; ?>
                </div> <!-- end container -->
            </div>
        </li>
        <script>
            $(document).on('click','#sendMessage', function(evt) {
                evt.preventDefault();
                var $btn = $(this);
                var contentmsg = $('input[name=msgcontent]').val();
                console.log(contentmsg);
                var courseId = $('input[name=class]').val();
                var userId = $('input[name=user]').val();
                $.ajax({
                    method: 'POST',
                    url:'/sendMessage',
                    data:{contentmsg:contentmsg,courseId:courseId,_token:$('input[name=_token]').val(),userId:userId},
                    success: function(data){
                        $('#msg').append('<li style="width: 100%"><div class="message-data align-right"><span class="message-data-name"><i class="fa fa-circle online"></i> <?php echo e(Auth::user()->name); ?></span> <span class="message-data-time">'+data.created_at+'</span> </div> <div class="message other-message float-right">'+data.content+' </div> </li>')
                    }
                });
                $('input[name=msgcontent]').val('');

            });
        </script>
    </ul>

                        </div> <!-- end chat-history -->

                    </div> <!-- end chat -->
                </div> <!-- end container -->
            </div>
        </li>

        <script>
            $(document).on('click','#sendMessage', function(evt) {
                evt.preventDefault();
                var $btn = $(this);
                var contentmsg = $('input[name=msgcontent]').val();
                console.log(contentmsg);
                var courseId = evt.target.dataset['class'];
                $.ajax({
                    method: 'POST',
                    url:'/sendMessage',
                    data:{contentmsg:contentmsg,courseId:courseId,_token:$('input[name=_token]').val()},
                    success: function(data){
                        $('#msg').append('<li style="width: 100%"><div class="message-data align-right"><span class="message-data-name"><i class="fa fa-circle online"></i> </span> <span class="message-data-time">'+data.created_at+'</span> </div> <div class="message other-message float-right">'+data.content+' </div> </li>')
                    }
                });
                $('input[name=msgcontent]').val('');

            });
        </script>
    </ul>
    <?php $__env->startSection('script'); ?>
    <?php $__env->stopSection(); ?>
    <script>
        $(function() {
            // Bind Click event to the drop down navigation button
            $(".nav-button").click(function() {
                /*  Toggle the CSS closed class which reduces the height of the UL thus
                 hiding all LI apart from the first */
                $(this).parent().parent().toggleClass("closed");
            });

        });
    </script>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>