<title>Register</title>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <!--first name-->
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--last name-->
                        <!--need change-->
                        <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Last Name</label>

                            <div class="col-md-6">
                                <input id="lastname" type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" required>

                                <?php if($errors->has('lastname')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--email-->
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--pwd-->
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--confirm pwd-->
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <!--position-->
                        <!--need change-->
                        <div class="form-group<?php echo e($errors->has('position') ? ' has-error' : ''); ?>">
                            <label for="position" class="col-md-4 control-label">Position</label>
                            <div class="col-md-6">
                                <select onchange="showMe(this);" id="position" type="text" class="form-control" name="position" value="<?php echo e(old('position')); ?>" required>
                                    <option>Student</option>
                                    <option>Instructor</option>
                                </select>
                                <?php if($errors->has('position')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('position')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--School/Institution-->
                        <!--need change-->
                        <div class="form-group<?php echo e($errors->has('school') ? ' has-error' : ''); ?>">
                            <label for="school" class="col-md-4 control-label">School/Institution</label>

                            <div class="col-md-6">
                                <input id="school" type="text" class="form-control" name="school" value="<?php echo e(old('school')); ?>" required>

                                <?php if($errors->has('school')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('school')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--student ID-->
                        <!--need change-->
                        <div class="form-group<?php echo e($errors->has('studentid') ? ' has-error' : ''); ?>" id="studentid">
                            <label for="studentid" class="col-md-4 control-label">Student ID</label>

                            <div class="col-md-6">
                                <input id="studentid" type="text" class="form-control" name="studentid" value="<?php echo e(old('studentid')); ?>">

                                <?php if($errors->has('studentid')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('studentid')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function showMe(e) {
        var strdisplay = e.options[e.selectedIndex].value;
        var e = document.getElementById("studentid");
        if(strdisplay == "Student") {
            e.style.display = "block";
        } else {
            e.style.display = "none";
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>